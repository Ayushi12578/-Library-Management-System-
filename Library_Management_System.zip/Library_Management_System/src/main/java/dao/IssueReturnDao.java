package dao;

public interface IssueReturnDao {
    void issueBook(String transactionId, String studentId, String bookId);
    void returnBook(String transactionId);
}
