package dao;

import app.DBConnection;
import java.sql.*;
import java.time.LocalDate;

public class IssueReturnDaoImpl implements IssueReturnDao {

    @Override
    public void issueBook(String transactionId, String studentId, String bookId) {

        String sql = "INSERT INTO issue_return VALUES(?,?,?,?,?,?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, transactionId);
            ps.setString(2, studentId);
            ps.setString(3, bookId);
            ps.setDate(4, Date.valueOf(LocalDate.now()));
            ps.setDate(5, null);
            ps.setString(6, "ISSUED");

            ps.executeUpdate();
            System.out.println("Book Issued Successfully!");

        } catch (Exception e) {
            System.out.println("Issue Error: " + e.getMessage());
        }
    }

    @Override
    public void returnBook(String transactionId) {

        String sql = "UPDATE issue_return SET returnDate=?, status='RETURNED' WHERE transactionId=?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setDate(1, Date.valueOf(LocalDate.now()));
            ps.setString(2, transactionId);

            int rows = ps.executeUpdate();
            if (rows > 0)
                System.out.println("Book Returned Successfully!");
            else
                System.out.println("Invalid Transaction ID!");

        } catch (Exception e) {
            System.out.println("Return Error: " + e.getMessage());
        }
    }
}
