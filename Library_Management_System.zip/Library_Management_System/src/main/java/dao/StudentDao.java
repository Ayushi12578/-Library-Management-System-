package dao;

import model.Student;

public interface StudentDao {
    void addStudent(Student s);
}
