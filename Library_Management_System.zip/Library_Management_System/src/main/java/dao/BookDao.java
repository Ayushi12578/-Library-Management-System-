package dao;

import model.Book;

public interface BookDao {
    void addBook(Book b);
}
