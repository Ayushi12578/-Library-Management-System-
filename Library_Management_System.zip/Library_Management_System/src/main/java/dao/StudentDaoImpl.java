package dao;

import app.DBConnection;
import model.Student;
import java.sql.*;

public class StudentDaoImpl implements StudentDao {

    @Override
    public void addStudent(Student s) {
        String sql = "INSERT INTO students VALUES(?,?,?,?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, s.getStudentId());
            ps.setString(2, s.getName());
            ps.setString(3, s.getCourse());
            ps.setString(4, s.getContact());
            ps.executeUpdate();

            System.out.println("Student Added!");

        } catch (Exception e) {
            System.out.println("Add Student Error: " + e.getMessage());
        }
    }
}
