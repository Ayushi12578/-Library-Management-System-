package dao;

import app.DBConnection;
import model.Book;
import java.sql.*;

public class BookDaoImpl implements BookDao {

    @Override
    public void addBook(Book b) {
        String sql = "INSERT INTO books VALUES(?,?,?,?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, b.getBookId());
            ps.setString(2, b.getTitle());
            ps.setString(3, b.getAuthor());
            ps.setInt(4, b.getQuantity());
            ps.executeUpdate();

            System.out.println("Book Added!");

        } catch (Exception e) {
            System.out.println("Add Book Error: " + e.getMessage());
        }
    }
}
