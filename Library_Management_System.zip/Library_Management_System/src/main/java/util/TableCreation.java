package util;

import java.sql.Connection;
import java.sql.Statement;
import app.DBConnection;

public class TableCreation {

    public static void init() {
        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement()) {

            String students = "CREATE TABLE IF NOT EXISTS students("
                    + "studentId VARCHAR(50) PRIMARY KEY,"
                    + "name VARCHAR(200),"
                    + "course VARCHAR(100),"
                    + "contact VARCHAR(50))";

            String books = "CREATE TABLE IF NOT EXISTS books("
                    + "bookId VARCHAR(50) PRIMARY KEY,"
                    + "title VARCHAR(200),"
                    + "author VARCHAR(200),"
                    + "quantity INT)";

            String issueReturn = "CREATE TABLE IF NOT EXISTS issue_return("
                    + "transactionId VARCHAR(50) PRIMARY KEY,"
                    + "studentId VARCHAR(50),"
                    + "bookId VARCHAR(50),"
                    + "issueDate DATE,"
                    + "returnDate DATE,"
                    + "status VARCHAR(20),"
                    + "FOREIGN KEY(studentId) REFERENCES students(studentId),"
                    + "FOREIGN KEY(bookId) REFERENCES books(bookId))";

            st.execute(students);
            st.execute(books);
            st.execute(issueReturn);

            System.out.println("Tables created successfully!");

        } catch (Exception e) {
            System.out.println("Table Creation Error: " + e.getMessage());
        }
    }
}
