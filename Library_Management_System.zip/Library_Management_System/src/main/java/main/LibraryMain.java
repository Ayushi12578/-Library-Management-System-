package main;

import dao.*;
import model.*;
import util.TableCreation;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Scanner;

public class LibraryMain {

    public static void main(String[] args) {

        TableCreation.init(); // create tables

        Scanner sc = new Scanner(System.in);

        StudentDao studentDAO = new StudentDaoImpl();
        BookDao bookD = new BookDaoImpl();
        IssueReturnDao issueDAO = new IssueReturnDaoImpl();

        while (true) {
            System.out.println("\n===== LIBRARY MENU =====");
            System.out.println("1. Add Student");
            System.out.println("2. Add Book");
            System.out.println("3. Issue Book");
            System.out.println("4. Return Book");
            System.out.println("5. Exit");
            System.out.print("Enter Choice: ");

            int ch = sc.nextInt();
            sc.nextLine();

            switch (ch) {

                case 1:
                    System.out.print("Student ID: ");
                    String sid = sc.nextLine();

                    System.out.print("Name: ");
                    String name = sc.nextLine();

                    System.out.print("Course: ");
                    String course = sc.nextLine();

                    System.out.print("Contact: ");
                    String contact = sc.nextLine();

                    studentDAO.addStudent(new Student(sid, name, course, contact));
                    break;

                case 2:
                    System.out.print("Book ID: ");
                    String bid = sc.nextLine();

                    System.out.print("Title: ");
                    String title = sc.nextLine();

                    System.out.print("Author: ");
                    String author = sc.nextLine();

                    System.out.print("Quantity: ");
                    int qty = sc.nextInt();

                    bookD.addBook(new Book(bid, title, author, qty));
                    break;

                case 3:
                    System.out.print("Transaction ID: ");
                    String tid = sc.nextLine();

                    System.out.print("Student ID: ");
                    String sid2 = sc.nextLine();

                    System.out.print("Book ID: ");
                    String bid2 = sc.nextLine();

                    issueDAO.issueBook(tid, sid2, bid2);
                    break;

                case 4:
                    System.out.print("Enter Transaction ID: ");
                    String tidr = sc.nextLine();

                    issueDAO.returnBook(tidr);
                    break;

                case 5:
                    System.out.println("Exiting...");
                    System.exit(0);
            }
        }
    }
}
