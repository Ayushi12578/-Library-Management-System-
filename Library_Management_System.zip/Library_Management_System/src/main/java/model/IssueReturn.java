package model;

import java.sql.Date;

public class IssueReturn {

    private String transactionId;
    private String studentId;
    private String bookId;
    private Date issueDate;
    private Date returnDate;
    private String status; // ISSUED / RETURNED

    public IssueReturn(String transactionId, String studentId, String bookId, Date issueDate, Date returnDate, String status) {
        this.transactionId = transactionId;
        this.studentId = studentId;
        this.bookId = bookId;
        this.issueDate = issueDate;
        this.returnDate = returnDate;
        this.status = status;
    }

    public String getTransactionId() { return transactionId; }
    public String getStudentId() { return studentId; }
    public String getBookId() { return bookId; }
    public Date getIssueDate() { return issueDate; }
    public Date getReturnDate() { return returnDate; }
    public String getStatus() { return status; }
}
