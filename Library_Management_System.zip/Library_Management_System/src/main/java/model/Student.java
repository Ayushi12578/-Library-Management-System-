package model;

public class Student {

    private String studentId;
    private String name;
    private String course;
    private String contact;

    public Student(String studentId, String name, String course, String contact) {
        this.studentId = studentId;
        this.name = name;
        this.course = course;
        this.contact = contact;
    }

    public String getStudentId() { return studentId; }
    public String getName() { return name; }
    public String getCourse() { return course; }
    public String getContact() { return contact; }
}
